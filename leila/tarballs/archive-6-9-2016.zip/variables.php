<?php
$db_hostname = '127.0.0.1';
$db_database = 'leila';
$db_username = 'leila';
$db_password = 'blabla';

$salt = "esh7Kie5";

// either imagick or gd. prefer imagick since it keeps aspect ratio
$imagelibrary = 'imagick';

// set 1 to enable guest to view the object list
// set 0 to disable guest access
$allowguests = 1;

// set 1 to make users valid by lending objects
// set 0 to make users valid by paying a fee
$usermustlend = 0;

$languages = ['de_DE' => 'Deutsch', 'en_EN' => 'English', 'fr_FR' => 'Français'];
$defaultlang = 'de_DE';

$fromemail = 'info@leihladen.at';
$fromname = 'Leila Berlin';
?>
